//
//  parcel.h
//  Algorithms - Parcel
//
//  Created by YourtionGuo on 05/05/2017.
//  Copyright © 2017 Yourtion. All rights reserved.
//

#ifndef PARCEL_H
#define PARCEL_H


/**
 包裹
 */
typedef struct Parcel_
{
  int       priority;

} Parcel;

#endif /* PARCEL_H */
